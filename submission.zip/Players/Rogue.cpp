#include "Rogue.h"

void Rogue::addCoins (const int coins_add){
    m_coins += 2*coins_add;
}
